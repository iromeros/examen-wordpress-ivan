{{ define "main" }}
	<span>
		<h1>{{ .Title }}</h1>
		{{ partial "post-meta" . }}
	</span>
	<p>{{ .Content }}</p>
	{{ partial "post-share" }}
{{ end }}
