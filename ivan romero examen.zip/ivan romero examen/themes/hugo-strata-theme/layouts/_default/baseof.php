{{ partial "head" . }}

<body id="top">
	{{ partial "header" . }}

	{{ "
	<!-- Main -->" | safeHTML }}
	<div id="main">
		{{ block "main" . }}{{ end }}
	</div>

	{{ partial "footer" . }}
</body>

</html>