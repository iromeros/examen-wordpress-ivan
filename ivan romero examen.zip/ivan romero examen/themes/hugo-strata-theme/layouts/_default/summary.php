<span>
    <h1><a href="{{ .Permalink }}">{{ .Title }}</a></h1>
    {{ partial "post-meta" . }}
</span>
<p>{{ .Summary }}</p>
<hr>