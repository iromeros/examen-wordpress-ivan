{{ if or (.Paginator.HasPrev) (.Paginator.HasNext) }}
    {{ if .Paginator.HasPrev }}
        <a class="button" rel="prev" href="{{ .Site.BaseURL }}{{.Paginator.Prev.URL}}">
            « Newer
        </a>
    {{ end }}

    {{ if and (.Paginator.HasPrev) (.Paginator.HasNext) }}
        <span class="spacer"></span>
    {{ end }}

    {{ if .Paginator.HasNext }}
        <a class="button" rel="next" href="{{ .Site.BaseURL }}{{.Paginator.Next.URL}}">
            Older »
        </a>
    {{ end }}
{{ end }}