
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>



	<title>{{ if .IsHome }}{{ .Site.Title }}{{ else }}{{ .Title }} &middot; {{ .Site.Title }}{{ end }}</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	{{ with .Site.Params.name }}
	<meta name="author" content="{{ . }}">{{ end }}
	{{ with .Site.Params.description }}
	<meta name="description" content="{{ . }}">{{ end }}
	{{ with .Site.LanguageCode }}
	<meta http-equiv="content-language" content="{{ . }}" />{{ end }}

	<meta prefix="og: http://ogp.me/ns#" property="og:type"
		content="{{ if .IsHome }}website{{ else }}article{{ end }}" />
	<meta prefix="og: http://ogp.me/ns#" property="og:url" name="url" content="{{ .Permalink }}">
	<meta prefix="og: http://ogp.me/ns#" property="og:title" name="title"
		content="{{ if .IsHome }}{{ .Site.Title }}{{ else }}{{ .Title }}{{ end }}">
	<meta prefix="og: http://ogp.me/ns#" property="og:description" name="description"
		content="{{ if .IsHome }}{{ .Site.Title }}{{ else }}{{ .Params.short_description }}{{ end }}" />
	<meta prefix="og: http://ogp.me/ns#" property="og:image" name="image"
		content="{{ .Site.BaseURL }}{{ if .IsHome }}images/{{ .Site.Params.sidebar.avatar }}{{ else }}{{ .Params.banner }}{{ end }}">

	<meta name="twitter:card" content="summary" />
	<meta name="twitter:site" content="@{{ .Site.Params.sidebar.twitter }}" />
	<meta name="twitter:title" content="{{ if .IsHome }}{{ .Site.Title }}{{ else }}{{ .Title }}{{ end }}" />
	<meta name="twitter:description"
		content="{{ if .IsHome }}{{ .Site.Title }}{{ else }}{{ .Params.short_description }}{{ end }}" />
	<meta name="twitter:image"
		content="{{ .Site.BaseURL }}{{ if .IsHome }}images/{{ .Site.Params.sidebar.avatar }}{{ else }}{{ .Params.banner }}{{ end }}" />

	<link rel="shortcut icon" href="{{ .Site.BaseURL }}favicon.ico" type="image/x-icon">
	<link rel="icon" href="{{ .Site.BaseURL }}favicon.ico" type="image/x-icon">
</head>

<body>
	{{ hugo.Generator }}

	{{ "
	<!--[if lte IE 8]>" | safeHTML }}<script src='{{ .Site.BaseURL }}js/ie/html5shiv.js'></script>{{ "<![endif]-->" |
	safeHTML}}
	<link rel="stylesheet" type="text/css"
		href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="{{ .Site.BaseURL }}css/main.css" />
	<link rel="stylesheet" href="{{ .Site.BaseURL }}css/syntax.css" />
	{{ "
	<!--[if lte IE 8]>" | safeHTML }}<link rel="stylesheet" href="{{ .Site.BaseURL }}/css/ie8.css">{{ "<![endif]-->" |
	safeHTML}}

	{{- with .Site.GetPage "/" }}
	{{ with .OutputFormats.Get "RSS" }}
	{{ printf `
	<link rel="%s" type="%s" href="%s" title="%s" />` .Rel .MediaType.Type .Permalink $.Site.Title | safeHTML }}
	{{ end -}}
	{{ end -}}
</body>

