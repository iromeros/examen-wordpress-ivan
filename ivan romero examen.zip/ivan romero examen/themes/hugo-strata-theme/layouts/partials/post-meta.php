<i class="fa fa-calendar"></i>&nbsp;&nbsp;
<time datetime="{{ .Date }}">{{ .Date.Format .Site.Params.date_format }}</time>&nbsp;&nbsp;

{{ if .Site.Params.Show_read_time }}{{ .ReadingTime }} min read&nbsp;&nbsp;{{ end }}

{{ if isset .Params "categories" }}
    {{ $categoriesLen := len .Params.categories }}
    {{ if gt $categoriesLen 0 }}
        <i class="fa fa-folder"></i>&nbsp;&nbsp;
        {{ range $k, $v := .Params.categories }}
        <a class="article-category-link" href="{{ $.Site.BaseURL }}categories/{{ . | urlize | lower }}">{{ . }}</a>
        {{ if lt $k (sub $categoriesLen 1) }}&middot;{{ end }}
        {{ end }}
    {{ end }}
{{ end }}

{{ if isset .Params "tags" }}
   {{ $tagsLen := len .Params.tags }}
   {{ if gt $tagsLen 0 }}
       &nbsp;&nbsp;<i class="fa fa-tags"></i>&nbsp;&nbsp;
       {{ range $k, $v := .Params.tags }}
       <a class="article-category-link" href="{{ $.Site.BaseURL }}tags/{{ . | urlize | lower }}">{{ . }}</a>
       {{ if lt $k (sub $tagsLen 1) }}&middot;{{ end }}
       {{ end }}
   {{ end }}
{{ end }}
