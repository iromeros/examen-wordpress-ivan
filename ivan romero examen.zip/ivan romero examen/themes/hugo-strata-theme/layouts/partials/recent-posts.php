<section>
{{ with .Site.Params.recentposts.title }}
<h1>Recent posts</h1>
{{ end }}
<div class="row">
    <p>
    <ol class="recent-posts">
        {{ $paginator := .Paginate (where .Site.RegularPages "Type" "post") }}
        {{ range first 5 $paginator.Pages }}
        {{ .Render "summary" }}
        {{ end }}
    </ol>
    </p>
</div>
</section>