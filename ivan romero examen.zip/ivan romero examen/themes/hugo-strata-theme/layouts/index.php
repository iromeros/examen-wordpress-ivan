{{ define "main" }}
	{{ partial "recent-posts" . }}
{{ end }}
